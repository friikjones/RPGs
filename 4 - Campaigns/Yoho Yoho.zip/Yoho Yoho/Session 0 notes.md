Rainbow Goblins
- The thing type creatures, hide amongst rainbow bears, bleed but do not tear


underdark flooded


Ship
- The Unlucky Rogers
- Flag: Silver coin on a clean background
- Reverse mermaid on the front
- 4 cannons

3 weeks of rations 



Petri
- Pus Gangrene
- Money, gun for hire

Const
- Grogcneck silverfang
- Got fired from a ship

Andre
- Rose
- Pirate out of poverty

Leo -> island backstory
- William
- Pirate because is cooler

Vlad
- Franky
- Pirate because of tradition, hate pirate customs